# Download

# BTCT-TimerCoin

TimerCoin创建于2019/02/22，是一种基于BTC技术的新型电子货币，采用了P2P技术，去中心化，任何人都能够使用它

TimerCoin的重要特点：出块时间为10分钟，初始块奖励为100单位，挖矿奖励的数量根据挖掘高度的增加按比例减少，每个新区块的奖励数量都将微量减少

TimerCoin如果保持15年不间断的挖矿，每个区块的产出将会从100不断减少至大约0.04，15年间的总量约为999万个

提供多平台的版本：WINDOWS/MACOS/IOS/安卓/UBUNTU/CENTOS/等

TimerCoin, founded in February 22, 2019, is a new electronic currency based on BTC technology. It adopts P2P technology and is decentralized. Anyone can use it.

TimerCoin's important features: 10 minutes of block time, 100 units of initial block reward, the number of mining rewards decreases proportionally according to the increase of mining height, and the number of rewards for each new block will be reduced slightly.

If Timer Coin keeps digging for 15 years, the output of each block will decrease from 100 to about 0.04, with a total of 9.99 million in 15 years.

Provide multi-platform versions: WINDOWS/MACOS/IOS/Android/UBUNTU/CENTOS/etc.


------------
BTCT-TimerCoin源代码 百度盘链接:https://pan.baidu.com/s/1z82WQz66cKcr7V9N2Ea_yw  密码:etnj
